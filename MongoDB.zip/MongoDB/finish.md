You have successfully deployed MongoDB on Docker in less than 5 minutes!

See you in the next scenario!
