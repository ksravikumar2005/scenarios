Welcome to the first scenario. Here you will be 

1. Creating a host based volume for persisting mongo files
2. launching a pre-built docker image for mongo
3. check the status of the mongo instance inside the container
4. stop and remove the conainer

All of this in less than 5 minutes.
